package Controller;

public class PropertyHotServlet {
}
